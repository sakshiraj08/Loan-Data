--TASK-1--
--Create a new database (named Loans) in SQL Server.
create database Loans
Use Loans

--Created Primary Key
ALTER TABLE dbo.banker_data
ADD PRIMARY KEY (banker_id)

ALTER TABLE dbo.customer_data
ADD PRIMARY KEY (customer_id)

ALTER TABLE dbo.home_loan_data
ADD PRIMARY KEY (loan_id)

-- Created the foreign key constraint
ALTER TABLE Loan_Records_Data
ADD CONSTRAINT FK_Loan_ID FOREIGN KEY (loan_id) REFERENCES Home_Loan_Data(loan_id);

ALTER TABLE Loan_Records_Data
ADD CONSTRAINT FK_customer_id FOREIGN KEY (customer_id) REFERENCES customer_data (customer_id);

ALTER TABLE Loan_Records_Data
ADD CONSTRAINT FK_banker_id FOREIGN KEY (banker_id) REFERENCES banker_data (banker_id);

--Import the 4 CSV files and generate 4 tables in the database. .
select * from Banker_Data
select * from Customer_Data
select * from Home_Loan_Data
select * from Loan_Records_Data

--Write a query to print all the databases available in the SQL Server.
select * from sys.databases where database_id>2

--Write a query to print the names of the tables from the Loans database.
select * from sys.tables 

--Write a query to print 5 records in each table--
select top 5 * from Banker_Data 
select top 5 * from Customer_Data
select top 5 * from Home_Loan_Data
select top 5 * from Loan_Records_Data

--TASK-2--
--1. Find the customer ID, first name, last name, and email of customers whose email address contains the term 'amazon'.
select customer_id,first_name,last_name,email from Customer_Data
where email like '%amazon%'

--2. Find the maximum property value (using appropriate alias) of each property type, ordered by the maximum property value in descending order.

select property_type, max(property_value) as maxpropertyvalue from Home_Loan_Data
group by property_type
order by maxpropertyvalue desc

--3.Find the number of home loans issued in San Francisco.
select count(loan_id) as Number_of_home_loans from Home_Loan_Data
where city= 'San Francisco'

--4.Find the city name and the corresponding average property value (using appropriate alias) for cities where the average property value is greater than $3,000,000.  
select city,avg(property_value) as AvgPropValue from Home_Loan_Data
group by city
having Avg(property_value)>3000000

--5. Find the average age (at the point of loan transaction, in years and nearest integer) of female customers who took a non-joint loan for townhomes.
select avg(datediff(year, c.dob, l.transaction_date)) as average_age
from Customer_Data as c
join Loan_Records_Data as l 
	on c.customer_id = l.customer_id
join 
    Home_Loan_Data as h 
	on h.loan_id = l.loan_id
join
    Banker_Data as b
	on b.banker_id=l.banker_id
where  c.gender = 'female'
       and h.property_type = 'townhome'
       and h.joint_loan = 'no'


--6.Find the names of the top 3 cities (based on descending alphabetical order) and corresponding loan percent (in ascending order) with the lowest average loan percent.  
select top 3 city, avg(loan_percent) as avgloanpercent from Home_Loan_Data
group by city
order by city desc, avgloanpercent

--7.Find the average loan term for loans not for semi-detached and townhome property types, and are in the following list of cities: 
--Sparks, Biloxi, Waco, Las Vegas, and Lansing.

select property_type,city,avg(loan_term) as avgloanterm from Home_Loan_Data
where property_type not in('semi-detached','townhome')
and city in('sparks','biloxi','waco','lacs vegas','lasing')
group by property_type,city

--8. Find the ID, first name, and last name of the top 2 bankers (and corresponding transaction count) involved in the highest number of distinct loan records.
select top 2 b.banker_id, b.first_name, b.last_name, count(distinct(l.record_id)) as DISTINCT_TRANSACTIONS 
from Banker_Data as b
join Loan_Records_Data as l  on b.banker_id = l.banker_id
group by b.banker_id, B.first_name, B.last_name 
order by count(distinct(l.record_id)) desc


--9.Find the total number of different cities for which home loans have been issued.

select city,count(distinct loan_id) as Totalnumber from Home_Loan_Data
group by city

--10.Find the average age of male bankers (years, rounded to 1 decimal place) based on the date they joined WBG.

select round (avg(datediff(YEAR, dob, date_joined)), 1) as avg_age 
from Banker_Data 
where gender = 'Male'

--TASK-3
--1. Create a stored procedure called `recent_joiners` that returns the ID, concatenated full name, date of birth, 
--and join date of bankers who joined within the recent 2 years (as of 1 Sep 2022) 
--Call the stored procedure `recent_joiners` you created above.

-- Create the stored procedure

CREATE PROCEDURE storepro_recent_joiners

AS
BEGIN
  
    SELECT
        banker_id AS ID,
        CONCAT(first_name, ' ', last_name) AS full_name,
        dob AS date_of_birth,
        date_joined
    FROM
        Banker_Data
    WHERE
        DATEDIFF(YEAR, date_joined,'2022-09-01') <= 2
END;

Exec storepro_recent_joiners

--2. Create a stored procedure called `city_and_above_loan_amt` that takes in two parameters (city_name, loan_amt_cutoff) that returns the full details of customers 
--with loans for properties in the input city and with loan amount greater than or equal to the input loan amount cutoff.  
--Call the stored procedure `city_and_above_loan_amt` you created above, based on the city San Francisco and loan amount cutoff of $1.5 million

CREATE PROCEDURE city_and_above_loan_amt
    @city_name NVARCHAR(250),
    @loan_amt_cutoff DECIMAL(20, 2)
AS
BEGIN
    SELECT 
        C.customer_id,
        C.first_name,
        C.last_name,
        C.email,
        C.gender,
        C.phone,
        C.dob,
        C.customer_since,
        H.property_type,
        H.property_value,
        H.loan_percent,
        H.loan_term,
        H.postal_code,
        H.joint_loan
    FROM 
        Customer_Data C
    JOIN 
        Loan_Records_Data L ON C.customer_id = L.customer_id
    JOIN 
        Home_Loan_Data H ON L.loan_id = H.loan_id
    WHERE 
        H.city = @city_name
        AND H.property_value >= @loan_amt_cutoff;
END


--Call the stored procedure city_and_above_loan_amt you created above, based on the city San Francisco and loan amount cutoff of $1.5 million 

EXEC city_and_above_loan_amt @city_name = 'San Francisco', @loan_amt_cutoff = 1500000

--3.Find the number of bankers involved in loans where the loan amount is greater than the average loan amount.
SELECT COUNT(DISTINCT b.banker_id) AS numb_bankers
FROM Banker_Data b 
JOIN Loan_Records_Data as l ON b.banker_id = l.banker_id
join Home_Loan_Data as h on h.loan_id=l.loan_id
cross join 
(
select avg(loan_term) AS avg_loan_amount FROM Home_Loan_Data) AS avg_loan
WHERE h.loan_term > avg_loan.avg_loan_amount

--4.Find the ID, first name and last name of customers with properties of value between $1.5 and $1.9 million, along with a new column 'tenure' that categorizes 
--how long the customer has been with WBG. 
--The 'tenure' column is based on the following logic:
--Long: Joined before 1 Jan 2015
--Mid: Joined on or after 1 Jan 2015, but before 1 Jan 2019
--Short: Joined on or after 1 Jan 2019
SELECT 
    C.customer_id,
    C.first_name,
    C.last_name,
    C.email,
    C.gender,
    C.phone,
    C.dob,
    C.customer_since,
    CASE 
        WHEN C.customer_since < '2015-01-01' THEN 'Long'
        WHEN C.customer_since >= '2015-01-01' AND C.customer_since < '2019-01-01' THEN 'Mid'
        WHEN C.customer_since >= '2019-01-01' THEN 'Short'
    END AS tenure
FROM 
    Customer_Data C
JOIN 
    Loan_Records_Data L ON C.customer_id = L.customer_id
JOIN 
    Home_Loan_Data H ON L.loan_id = H.loan_id
WHERE 
    H.property_value BETWEEN 1500000 AND 1900000


--5.Find the ID and full name (first name concatenated with last name) of customers who were served by bankers aged below 30 (as of 1 Aug 2022).
SELECT c.customer_id, CONCAT(c.first_name, ' ', c.last_name) AS Full_Name
FROM Customer_Data c 
JOIN Loan_Records_Data as l on l.customer_id=c.customer_id
INNER JOIN Banker_Data b ON b.banker_id = l.banker_id
WHERE datediff(YEAR, b.dob, '2022-08-01') < 30

--6.Find the number of Chinese customers with joint loans with property values less than $2.1 million, and served by female bankers.
SELECT COUNT(DISTINCT c.customer_id) AS num_customers
FROM Customer_Data c
JOIN Loan_Records_Data as l ON c.customer_id = l.customer_id
JOIN Banker_Data as b ON l.banker_id = b.banker_id
JOIN Home_Loan_Data AS h ON h.loan_id=l.loan_id
WHERE c.nationality = 'China'
    AND h.property_type = 'joint'
    AND h.property_value < 2100000
    AND b.gender = 'Female'

--7. Find the top 3 transaction dates (and corresponding loan amount sum) for which the sum of loan amount issued on that date is the highest.
SELECT TOP 3 transaction_date FROM Loan_Records_Data
SELECT SUM(loan_term) AS total_loan_amount
FROM Home_Loan_Data
ORDER BY total_loan_amount DESC

--8. Find the sum of the loan amounts ((i.e., property value x loan percent / 100) for each banker ID, excluding properties based in the cities of Dallas and Waco. 
--The sum values should be rounded to nearest integer. 

SELECT banker_id FROM Loan_Records_Data
SELECT ROUND(SUM(property_value * loan_percent / 100),0) AS total_loan_amount
FROM Home_Loan_Data
WHERE city NOT IN ('Dallas', 'Waco')


--9.Create a view called `dallas_townhomes_gte_1m` which returns all the details of loans involving properties of townhome type, located in Dallas,
-- and have loan amount of >$1 million.

CREATE VIEW dallas_townhomes_gte_1m AS
SELECT *
    FROM
    Home_Loan_Data
SELECT property_value * (loan_percent / 100) AS loan_amount from Home_Loan_Data
WHERE
    property_type = 'townhome'
    AND city = 'Dallas'
    AND sum(loan_term) > 1000000






